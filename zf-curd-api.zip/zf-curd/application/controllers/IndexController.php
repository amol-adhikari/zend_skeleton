<?php

class IndexController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        $router = new Application_Model_DbTable_Router();
        $this->view->router = $router->fetchAll();
    }

    public function addAction()
    {
        $form = new Application_Form_Router();
        $form->submit->setLabel('Add');
        $this->view->form = $form;
        
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                $sapid = $form->getValue('sapid');
                $hostname = $form->getValue('hostname');
                $loopback = $form->getValue('loopback');
                $mac_address = $form->getValue('mac_address');
                $router = new Application_Model_DbTable_Router();
                $router->addRouter($sapid, $hostname, $loopback, $mac_address);
                
                $this->_helper->redirector('index');
            } else {
                $form->populate($formData);
            }
        }
            
    }

    public function editAction()
    {
        $form = new Application_Form_Router();
        $form->submit->setLabel('Save');
        $this->view->form = $form;
        
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                $id = $form->getValue('id');
                $sapid = $form->getValue('sapid');
                $hostname = $form->getValue('hostname');
                $loopback = $form->getValue('loopback');
                $mac_address = $form->getValue('mac_address');
                $router = new Application_Model_DbTable_Router();
                $router->updateRouter($id, $sapid, $hostname, $loopback, $mac_address);
                
                $this->_helper->redirector('index');
            } else {
                $form->populate($formData);
            }
        } else {
            $id = $this->_getParam('id', 0);
            if ($id > 0) {
                $router = new Application_Model_DbTable_Router();
                $form->populate($router->getRouter($id));
            }
        }
        
    }

    public function deleteAction()
    {
        if ($this->getRequest()->isPost()) {
            $del = $this->getRequest()->getPost('del');
            if ($del == 'Yes') {
                $id = $this->getRequest()->getPost('id');
                $router = new Application_Model_DbTable_Router();
                $router->deleteRouter($id);
            }
            $this->_helper->redirector('index');
        } else {
            $id = $this->_getParam('id', 0);
            $router = new Application_Model_DbTable_Router();
            $this->view->router = $router->getRouter($id);
        }
    }


}







