<?php

class ApiController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
		
    }

    public function indexAction()
    {
		
		$form = new Application_Form_Router();
        $form->submit->setLabel('Add');
        $this->view->form = $form;
    }
	
	public function gettokenAction() {
		$this->_helper->layout()->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		
        $data = file_get_contents("php://input");
        $decode_data = json_decode($data, true);
		
		$apiAuthNamespace = new Zend_Session_Namespace('api_AuthNamespace');
		
		$ip = $_SERVER['REMOTE_ADDR'];
		$api = new Application_Model_DbTable_Api();
		$token = $api->getToken();
		if($token) {
			$reponse = array(
				'token' => $token
			);
		} else {
			$token = $api->generateToken();
		}
		$apiAuthNamespace->token =  $token;
		
		echo json_encode($reponse);
		die;
	}
	
	public function addAction()
    {
		$apiAuthNamespace = new Zend_Session_Namespace('api_AuthNamespace');
        $form = new Application_Form_Router();
        $form->submit->setLabel('Add');
        $this->view->form = $form;
        $this->view->token = $apiAuthNamespace->token;
        
        if ($this->getRequest()->isPost()) {
            $formData = $this->getRequest()->getPost();
            if ($form->isValid($formData)) {
                $sapid = $form->getValue('sapid');
                $hostname = $form->getValue('hostname');
                $loopback = $form->getValue('loopback');
                $mac_address = $form->getValue('mac_address');
                $router = new Application_Model_DbTable_Router();
                $router->addRouter($sapid, $hostname, $loopback, $mac_address);
                
                $this->_helper->redirector('index');
            } else {
                $form->populate($formData);
            }
        }
            
    }
	
	public function addrouterAction() {
		$this->_helper->layout()->disableLayout();
		$this->_helper->viewRenderer->setNoRender(true);
		
        $data = file_get_contents("php://input");
        $decode_data = json_decode($data, true);
		$api = new Application_Model_DbTable_Api();
		if($api->validateToken($decode_data['token'])) {		
			$router = new Application_Model_DbTable_Router();
			$router->addRouter($decode_data['sapid'],$decode_data['hostname'], $decode_data['loopback'], $decode_data['mac_address']);
			echo 'router added';
		} else {
			echo 'invalid token';
		}
		die;
	}


}







