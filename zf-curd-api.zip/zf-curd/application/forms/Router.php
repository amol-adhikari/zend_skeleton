<?php

class Application_Form_Router extends Zend_Form
{
    public function init()
    {
        $this->setName('router');

        $id = new Zend_Form_Element_Hidden('id');
        $id->addFilter('Int');

        $sapid = new Zend_Form_Element_Text('sapid');
        $sapid->setLabel('Sapid')
               ->setRequired(true)
               ->addFilter('StripTags')
               ->addFilter('StringTrim')
               ->addValidator('NotEmpty')
			   ->addValidator('regex', false, array(
													'pattern'=>'/^[A-Za-z, 0-9_@%&*]{6,32}$/',
													'messages'=>array(
															'regexNotMatch'=>'Invalide input'
													)
											)
							)
				
			   ->addValidator('StringLength', false, array(18, 18));

        $hostname = new Zend_Form_Element_Text('hostname');
        $hostname->setLabel('Hostname')
              ->setRequired(true)
              ->addFilter('StripTags')
              ->addFilter('StringTrim')
              ->addValidator('NotEmpty')
			  ->addValidator('regex', false, array('pattern'=>'/^[A-Z0-9_@%&*]{6,32}$/', 'messages'=>array('regexNotMatch'=>'Invalid Input')))
			  ->addValidator('StringLength', false, array(14, 14));
			  
		$loopback = new Zend_Form_Element_Text('loopback');
		$loopback->setLabel('Loopback')
			->setRequired(true)
			->addFilter('StripTags')
			->addFilter('StringTrim')
			->addValidator('NotEmpty')
			->addValidator('regex', false, array('pattern'=>'/^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/', 'messages'=>array('regexNotMatch'=>'Invalid Input')))
			->addValidator('StringLength', false, array(7, 15));
			
		$mac_address = new Zend_Form_Element_Text('mac_address');
		$mac_address->setLabel('Mac Address')
					->setRequired(true)
					->addFilter('StripTags')
					->addFilter('StringTrim')
					->addValidator('NotEmpty')
					->addValidator('regex', false, array('pattern'=> '/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/', 'messages'=>array('regexNotMatch'=> 'Invalid Input')))
					->addValidator('StringLength', false, array(17, 17));

        $submit = new Zend_Form_Element_Submit('submit');
        $submit->setAttrib('id', 'submitbutton');

        $this->addElements(array($id, $sapid, $hostname, $loopback, $mac_address, $submit));
    }
}