<?php

class Application_Model_DbTable_Api extends Zend_Db_Table_Abstract
{

    protected $_name = 'api';

    public function getToken()
    {
        $row = $this->fetchRow('ip = "' . $_SERVER['REMOTE_ADDR'] .'"');
        if (!$row) {
            return false;
        }
        return $row->toArray();
    }
	
	public function generateToken() {
		$token = md5(uniqid(time().$_SERVER['REMOTE_ADDR'], true));
		$data = array(
			'ip' => $_SERVER['REMOTE_ADDR'],
			'token' => $token
		);
		
		$this->insert($data);
		return $token;
	}

	public function validateToken($token) {
		$result = false;
		$select = $this->_db->select();
		$select->from($this->_name, array('token'))
				->where('token = ?', $token)
				->where('ip = ? ', $_SERVER['REMOTE_ADDR']);
		$result = $this->_db->fetchRow($select);
		
		return $result;
	}
}

