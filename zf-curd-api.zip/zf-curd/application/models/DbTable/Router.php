<?php

class Application_Model_DbTable_Router extends Zend_Db_Table_Abstract
{

    protected $_name = 'router';

    public function getRouter($id)
    {
        $id = (int)$id;
        $row = $this->fetchRow('id = ' . $id);
        if (!$row) {
            throw new Exception("Could not find row $id");
        }
        return $row->toArray();
    }

    public function addRouter($sapid, $hostname, $loopback, $mac_address)
    {
        $data = array(
            'sapid' => $sapid,
            'hostname' => $hostname,
            'loopback' => $loopback,
            'mac_address' => $mac_address,
        );
        $this->insert($data);
    }

    public function updateRouter($id, $sapid, $hostname, $loopback, $mac_address)
    {
        $data = array(
            'sapid' => $sapid,
            'hostname' => $hostname,
            'loopback' => $loopback,
            'mac_address' => $mac_address,
        );
        $this->update($data, 'id = '. (int)$id);
    }

    public function deleteRouter($id)
    {
        $this->delete('id =' . (int)$id);
    }

}

